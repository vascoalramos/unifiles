module.exports = {
    user: "orcl_monitor",
    password: "secret",
    connectString: "localhost:1521/orclmonitor.localdomain",
};
