encoding = "UTF-8"

username_root = "sys"
password_root = "Oradoc_db1"
dsn_root = "localhost/ORCLCDB.localdomain"

username = "system"
password = "Oradoc_db1"
dsn = "localhost/orclpdb1.localdomain"

username2 = "orcl_monitor"
password2 = "secret"
dsn2 = "localhost/orclmonitor.localdomain"
