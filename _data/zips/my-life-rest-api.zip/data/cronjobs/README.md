# Cronjobs documentation

The main objective of this cronjobs is to send notifications to My Life users in specific times of a day.

## Resources  

* [https://medium.com/rocketseat/push-notification-no-ios-e-android-com-react-native-66e956c89f5f](https://medium.com/rocketseat/push-notification-no-ios-e-android-com-react-native-66e956c89f5f)

* [https://medium.com/@gavinwiener/how-to-schedule-a-python-script-cron-job-dea6cbf69f4e](https://medium.com/@gavinwiener/how-to-schedule-a-python-script-cron-job-dea6cbf69f4e)

* [https://pynative.com/python-postgresql-tutorial/](https://pynative.com/python-postgresql-tutorial/)