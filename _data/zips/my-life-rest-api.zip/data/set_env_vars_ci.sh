#!/bin/bash

export SECRET_KEY='#s6$ds9t*ui7@=2bt77h50w2g&i6n9p#krfb&03jk4v^%_5)i7'
export DATABASE_NAME='postgres'
export DATABASE_USER='postgres'
export DATABASE_PASSWORD='postgres'
export DATABASE_HOST='postgres'
export DATABASE_PORT='5432'
