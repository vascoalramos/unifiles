#!/bin/bash

export SECRET_KEY='#s6$ds9t*ui7@=2bt77h50w2g&i6n9p#krfb&03jk4v^%_5)i7'

export DATABASE_NAME='mylife'
export DATABASE_USER='mylife'
export DATABASE_PASSWORD='mylife-restapi-2020'
export DATABASE_HOST='localhost'
export DATABASE_PORT='5432'
