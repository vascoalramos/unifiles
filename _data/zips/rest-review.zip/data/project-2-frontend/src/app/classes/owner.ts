export class Owner {
  email: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  photo: string;
  n_of_rests: number;
}
