export class Client {
  email: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  photo: string;
  number_of_reviews: number;
}
