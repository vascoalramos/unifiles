import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-base-register',
  templateUrl: './base-register.component.html',
  styleUrls: ['./base-register.component.css']
})
export class BaseRegisterComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
