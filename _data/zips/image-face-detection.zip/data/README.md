# Image Face Detection

Repository home to the source code of the second project done in one of our classes: [Machine Learning Topics](https://www.ua.pt/en/uc/12832). Its purpose is to implement and compare the results of face detecion based on images with SVM and Neural Networks.

## Authors

-   **João Vasconcelos:** [jmnmv12](https://github.com/jmnmv12)
-   **Vasco Ramos:** [vascoalramos](https://github.com/vascoalramos)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
